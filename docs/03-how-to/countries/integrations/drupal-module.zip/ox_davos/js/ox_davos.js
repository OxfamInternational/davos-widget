Drupal.behaviors.oxDavos = {
  attach: function (context, settings) {
    once('oxDavos', 'html').forEach(function (element) {
      const davosWidget = new DavosWidget('/modules/custom/ox_davos/widget-code/davos-widget-cta.json', '/modules/custom/ox_davos/widget-code/davos-widget.json');
        davosWidget.setup();
      })
  }
};
